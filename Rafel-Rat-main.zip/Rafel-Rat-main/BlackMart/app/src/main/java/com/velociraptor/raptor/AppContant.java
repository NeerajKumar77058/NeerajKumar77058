package com.velociraptor.raptor;

public class AppContant {
    public double getLatitude = 0.0;
    public double getLongitude = 0.0;
}
